package me.travis.wurstplus.module.modules.memes;

import me.travis.wurstplus.module.Module;

@Module.Info(name = "No Feet Damage", category = Module.Category.MEMES)
public class nofeetdamage extends Module {

}