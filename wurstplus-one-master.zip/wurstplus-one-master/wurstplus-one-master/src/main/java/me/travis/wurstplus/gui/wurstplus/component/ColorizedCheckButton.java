package me.travis.wurstplus.gui.wurstplus.component;

import me.travis.wurstplus.gui.rgui.component.use.CheckButton;

/**
 * Created by 086 on 8/08/2017.
 */
public class ColorizedCheckButton extends CheckButton {
    public ColorizedCheckButton(String name) {
        super(name);
    }
}
