package me.travis.wurstplus.gui.rgui.layout;

import me.travis.wurstplus.gui.rgui.component.container.Container;

/**
 * Created by 086 on 26/06/2017.
 */
public interface Layout {

    public void organiseContainer(Container container);

}
