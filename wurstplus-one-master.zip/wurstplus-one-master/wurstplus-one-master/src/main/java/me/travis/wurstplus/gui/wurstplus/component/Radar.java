package me.travis.wurstplus.gui.wurstplus.component;

import me.travis.wurstplus.gui.rgui.component.AbstractComponent;

/**
 * Created by 086 on 11/08/2017.
 */
public class Radar extends AbstractComponent {
}
