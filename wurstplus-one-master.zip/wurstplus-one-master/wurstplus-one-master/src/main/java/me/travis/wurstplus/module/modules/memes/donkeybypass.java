package me.travis.wurstplus.module.modules.memes;

import me.travis.wurstplus.module.Module;

@Module.Info(name = "Dokey Bypass", category = Module.Category.MEMES)
public class donkeybypass extends Module {

}