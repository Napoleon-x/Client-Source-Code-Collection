package me.travis.wurstplus.gui.rgui.poof.use;

import me.travis.wurstplus.gui.rgui.component.Component;
import me.travis.wurstplus.gui.rgui.poof.PoofInfo;

/**
 * Created by 086 on 21/07/2017.
 */
public abstract class AdditionPoof<T extends Component, S extends PoofInfo> extends Poof<T, S> {
}
