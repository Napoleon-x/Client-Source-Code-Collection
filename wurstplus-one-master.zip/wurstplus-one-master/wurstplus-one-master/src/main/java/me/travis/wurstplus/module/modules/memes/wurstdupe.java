package me.travis.wurstplus.module.modules.memes;

import me.travis.wurstplus.module.Module;

@Module.Info(name = "Wurst+ Dupe", category = Module.Category.MEMES)
public class wurstdupe extends Module {

}