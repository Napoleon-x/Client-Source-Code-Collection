package me.travis.wurstplus.gui.wurstplus.theme.wurstplus;

import me.travis.wurstplus.gui.wurstplus.component.Chat;
import me.travis.wurstplus.gui.rgui.render.AbstractComponentUI;

/**
 * Created by 086 on 2/08/2017.
 */
public class RootChatUI extends AbstractComponentUI<Chat> {
}
