package me.travis.wurstplus.module.modules.render;

import me.travis.wurstplus.module.Module;

/**
 * Created by 086 on 24/12/2017.
 * @see me.travis.wurstplus.mixin.client.MixinGuiScreen
 */
@Module.Info(name = "ShulkerPreview", category = Module.Category.RENDER)
public class ShulkerPreview extends Module {
}
