/*
 * Decompiled with CFR 0.145.
 */
package me.travis.wurstplus.event.events;

public class DisplaySizeChangedEvent {
}

