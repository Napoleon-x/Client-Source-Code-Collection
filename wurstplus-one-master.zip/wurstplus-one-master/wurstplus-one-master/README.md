# ☣️ WARNING ☣️ SHITTY KAMI PASTE AHEAD ☣️

no, wurst+2 contains none of this code, join the wurst+2 discord here: https://discord.gg/SKDTQJn

## what

> this is wurst+ 1, a client i made in october / novemeber 2019.
> it was a project for me to learn java, shit is all over the place, well over half the code is pasted from 17 different places.
> you shouldn't paste from this, ive learned from my mistakes and i dont want you to follow my horrible example

## why

> shanks ace got token logged (again) and this time apprently wurst+ was leaked (again) and people told me to make the client public (again), so i made the src public instead.
> also, the dms show that naughty (864) made a small fucktonne off this client while i was on break. i was not aware of this and never saw a penny of the money.

## Installation

> just build the gradle, im not providing any compiled code
