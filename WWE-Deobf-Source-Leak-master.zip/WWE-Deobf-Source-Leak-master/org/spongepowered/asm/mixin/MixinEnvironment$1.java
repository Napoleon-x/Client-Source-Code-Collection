package org.spongepowered.asm.mixin;

static class MixinEnvironment$1 {}