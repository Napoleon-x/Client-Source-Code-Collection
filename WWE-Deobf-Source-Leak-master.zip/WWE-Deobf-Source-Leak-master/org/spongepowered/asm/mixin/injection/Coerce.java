package org.spongepowered.asm.mixin.injection;

import java.lang.annotation.*;

@Target({ ElementType.PARAMETER })
public @interface Coerce {
}
