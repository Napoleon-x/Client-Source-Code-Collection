package org.spongepowered.asm.mixin;

enum MixinEnvironment$CompatibilityLevel$3
{
    MixinEnvironment$CompatibilityLevel$3(final String s, final int n, final int n2, final int n3, final boolean b) {
    }
    
    @Override
    boolean isSupported() {
        return false;
    }
}