package baritone;

import baritone.api.utils.*;

public final class cm implements cr
{
    final IPlayerContext a;
    int a;
    
    public cm(final IPlayerContext a) {
        super();
        this.a = a;
    }
}
