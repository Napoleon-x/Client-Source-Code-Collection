package baritone.api.cache;

public interface IWorldProvider
{
    IWorldData getCurrentWorld();
}
