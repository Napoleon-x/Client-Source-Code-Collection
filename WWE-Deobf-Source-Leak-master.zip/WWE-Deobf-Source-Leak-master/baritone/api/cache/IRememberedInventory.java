package baritone.api.cache;

import java.util.*;

public interface IRememberedInventory
{
    List<aip> getContents();
    
    int getSize();
}
