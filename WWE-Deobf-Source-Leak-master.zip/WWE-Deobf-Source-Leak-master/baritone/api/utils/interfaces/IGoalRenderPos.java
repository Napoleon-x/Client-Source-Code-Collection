package baritone.api.utils.interfaces;

public interface IGoalRenderPos
{
    et getGoalPos();
}
