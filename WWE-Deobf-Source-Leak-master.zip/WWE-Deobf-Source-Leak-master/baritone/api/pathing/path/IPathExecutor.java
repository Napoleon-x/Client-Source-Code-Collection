package baritone.api.pathing.path;

import baritone.api.pathing.calc.*;

public interface IPathExecutor
{
    IPath getPath();
    
    int getPosition();
}
