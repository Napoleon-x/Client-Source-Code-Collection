package baritone.api.process;

public interface IGetToBlockProcess extends IBaritoneProcess
{
    void getToBlock(final aow p0);
}
