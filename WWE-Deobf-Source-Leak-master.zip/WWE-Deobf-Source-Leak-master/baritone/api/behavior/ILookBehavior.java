package baritone.api.behavior;

import baritone.api.utils.*;

public interface ILookBehavior extends IBehavior
{
    void updateTarget(final Rotation p0, final boolean p1);
}
