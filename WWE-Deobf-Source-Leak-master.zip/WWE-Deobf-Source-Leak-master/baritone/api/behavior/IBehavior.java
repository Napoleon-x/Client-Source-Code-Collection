package baritone.api.behavior;

import baritone.api.event.listener.*;

public interface IBehavior extends AbstractGameEventListener
{
}
