package baritone.api;

class Settings$1
{
}
