package baritone;

final class bo
{
    static final int[] a;
    
    static {
        a = new int[ag.a().length];
        try {
            final int[] a2 = bo.a;
            final int a3 = ag.a;
            a2[0] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            final int[] a4 = bo.a;
            final int b = ag.b;
            a4[1] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
    }
}
