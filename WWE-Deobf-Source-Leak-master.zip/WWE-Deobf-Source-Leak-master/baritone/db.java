package baritone;

import java.io.*;

public interface db
{
    File getChunkSaveLocation();
}
