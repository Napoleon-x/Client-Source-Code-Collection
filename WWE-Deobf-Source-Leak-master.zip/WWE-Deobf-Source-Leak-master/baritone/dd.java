package baritone;

public interface dd
{
    ayf getChunkLoader();
}
