package baritone;

import it.unimi.dsi.fastutil.longs.*;

public interface dc
{
    Long2ObjectMap<axw> loadedChunks();
}
