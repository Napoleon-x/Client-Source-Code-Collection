package baritone;

final class i
{
    final long a;
    final int a;
    final String a;
    final et a;
    
    private i(final long a, final int a2, final String a3, final et a4) {
        super();
        this.a = a;
        this.a = a2;
        this.a = a3;
        this.a = a4;
        System.out.println("Future inventory created " + a + " " + a2 + " " + a3 + " " + a4);
    }
    
    i(final long n, final int n2, final String s, final et et, final byte b) {
        this(n, n2, s, et);
    }
}
