package baritone;

import baritone.api.utils.*;

public final class bz
{
    final int a;
    final et a;
    final fa a;
    final Rotation a;
    private bs a;
    
    public bz(final bs a, final int a2, final et a3, final fa a4, final Rotation a5) {
        this.a = a;
        super();
        this.a = a2;
        this.a = a3;
        this.a = a4;
        this.a = a5;
    }
}
