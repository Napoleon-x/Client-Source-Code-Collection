package baritone;

import baritone.api.utils.*;

enum ay
{
    ay(final String s) {
    }
    
    @Override
    public final ae a(final ad ad, final BetterBlockPos betterBlockPos) {
        return bl.a(ad, betterBlockPos, fa.e);
    }
    
    @Override
    public final void a(final ad ad, final int n, final int n2, final int n3, final dh dh) {
        bl.a(ad, n, n2, n3, fa.e, dh);
    }
}
