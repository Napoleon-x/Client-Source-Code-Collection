package baritone;

final class cs implements cr
{
    cs() {
        super();
    }
}
