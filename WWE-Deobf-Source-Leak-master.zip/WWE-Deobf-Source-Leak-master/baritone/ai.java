package baritone;

import baritone.api.utils.*;

public final class ai
{
    public Rotation a;
    boolean a;
    
    public ai() {
        this(null, false);
    }
    
    public ai(final Rotation a, final boolean a2) {
        super();
        this.a = a;
        this.a = a2;
    }
}
