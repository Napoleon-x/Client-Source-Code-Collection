/*
 * Decompiled with CFR 0.143.
 */
package net.minecraft.util;

public interface IStringSerializable {
    public String getName();
}

