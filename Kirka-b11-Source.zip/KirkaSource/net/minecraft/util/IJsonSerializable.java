/*
 * Decompiled with CFR 0.143.
 */
package net.minecraft.util;

import com.google.gson.JsonElement;

public interface IJsonSerializable {
    public void func_152753_a(JsonElement var1);

    public JsonElement getSerializableElement();
}

