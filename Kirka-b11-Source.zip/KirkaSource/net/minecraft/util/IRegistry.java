/*
 * Decompiled with CFR 0.143.
 */
package net.minecraft.util;

public interface IRegistry
extends Iterable {
    public Object getObject(Object var1);

    public void putObject(Object var1, Object var2);
}

