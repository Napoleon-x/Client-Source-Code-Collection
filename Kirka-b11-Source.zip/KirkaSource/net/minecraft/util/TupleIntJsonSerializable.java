/*
 * Decompiled with CFR 0.143.
 */
package net.minecraft.util;

import net.minecraft.util.IJsonSerializable;

public class TupleIntJsonSerializable {
    private int integerValue;
    private IJsonSerializable jsonSerializableValue;
    private static final String __OBFID = "CL_00001478";

    public int getIntegerValue() {
        return this.integerValue;
    }

    public void setIntegerValue(int p_151188_1_) {
        this.integerValue = p_151188_1_;
    }

    public IJsonSerializable getJsonSerializableValue() {
        return this.jsonSerializableValue;
    }

    public void setJsonSerializableValue(IJsonSerializable p_151190_1_) {
        this.jsonSerializableValue = p_151190_1_;
    }
}

