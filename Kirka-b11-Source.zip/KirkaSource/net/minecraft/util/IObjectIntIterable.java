/*
 * Decompiled with CFR 0.143.
 */
package net.minecraft.util;

public interface IObjectIntIterable
extends Iterable {
}

