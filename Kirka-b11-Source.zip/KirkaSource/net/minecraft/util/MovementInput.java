/*
 * Decompiled with CFR 0.143.
 */
package net.minecraft.util;

public class MovementInput {
    public static float moveStrafe;
    public static float moveForward;
    public boolean jump;
    public boolean sneak;
    private static final String __OBFID = "CL_00000936";

    public void updatePlayerMoveState() {
    }
}

