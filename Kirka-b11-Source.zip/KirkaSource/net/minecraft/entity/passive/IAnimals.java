/*
 * Decompiled with CFR 0.143.
 */
package net.minecraft.entity.passive;

public interface IAnimals {
}

