/*
 * Decompiled with CFR 0.143.
 */
package net.minecraft.entity;

public interface IEntityLivingData {
}

