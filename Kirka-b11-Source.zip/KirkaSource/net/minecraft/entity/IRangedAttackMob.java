/*
 * Decompiled with CFR 0.143.
 */
package net.minecraft.entity;

import net.minecraft.entity.EntityLivingBase;

public interface IRangedAttackMob {
    public void attackEntityWithRangedAttack(EntityLivingBase var1, float var2);
}

