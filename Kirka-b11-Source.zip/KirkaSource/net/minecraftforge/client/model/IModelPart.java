/*
 * Decompiled with CFR 0.143.
 */
package net.minecraftforge.client.model;

public interface IModelPart {
}

