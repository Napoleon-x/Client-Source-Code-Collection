/*
 * Decompiled with CFR 0.143.
 */
package javassist.util.proxy;

import javassist.util.proxy.MethodHandler;

public interface Proxy {
    public void setHandler(MethodHandler var1);
}

