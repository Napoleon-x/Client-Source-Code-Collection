/*
 * Decompiled with CFR 0.143.
 */
package javassist.util.proxy;

import java.lang.reflect.Method;

public interface MethodFilter {
    public boolean isHandled(Method var1);
}

