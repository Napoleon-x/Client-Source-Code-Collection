/*
 * Decompiled with CFR 0.143.
 */
package javassist.util;

class Trigger {
    Trigger() {
    }

    void doSwap() {
    }
}

