/*
 * Decompiled with CFR 0.143.
 */
package javassist.tools.rmi;

public interface Proxy {
    public int _getObjectId();
}

