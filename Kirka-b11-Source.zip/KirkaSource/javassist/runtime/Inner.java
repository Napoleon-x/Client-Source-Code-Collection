/*
 * Decompiled with CFR 0.143.
 */
package javassist.runtime;

public class Inner {
}

