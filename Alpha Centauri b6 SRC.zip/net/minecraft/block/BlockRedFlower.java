package net.minecraft.block;

import net.minecraft.block.BlockFlower;

public class BlockRedFlower extends BlockFlower {
   public BlockFlower.EnumFlowerColor getBlockType() {
      return BlockFlower.EnumFlowerColor.RED;
   }
}
