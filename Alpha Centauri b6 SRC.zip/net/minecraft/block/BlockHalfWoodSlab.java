package net.minecraft.block;

import net.minecraft.block.BlockWoodSlab;

public class BlockHalfWoodSlab extends BlockWoodSlab {
   public boolean isDouble() {
      return false;
   }
}
