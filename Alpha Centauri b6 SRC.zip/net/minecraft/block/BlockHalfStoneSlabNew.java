package net.minecraft.block;

import net.minecraft.block.BlockStoneSlabNew;

public class BlockHalfStoneSlabNew extends BlockStoneSlabNew {
   public boolean isDouble() {
      return false;
   }
}
