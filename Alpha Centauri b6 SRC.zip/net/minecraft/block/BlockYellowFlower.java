package net.minecraft.block;

import net.minecraft.block.BlockFlower;

public class BlockYellowFlower extends BlockFlower {
   public BlockFlower.EnumFlowerColor getBlockType() {
      return BlockFlower.EnumFlowerColor.YELLOW;
   }
}
