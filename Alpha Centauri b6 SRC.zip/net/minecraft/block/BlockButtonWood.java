package net.minecraft.block;

import net.minecraft.block.BlockButton;

public class BlockButtonWood extends BlockButton {
   protected BlockButtonWood() {
      super(true);
   }
}
