package net.minecraft.block;

import net.minecraft.block.BlockWoodSlab;

public class BlockDoubleWoodSlab extends BlockWoodSlab {
   public boolean isDouble() {
      return true;
   }
}
