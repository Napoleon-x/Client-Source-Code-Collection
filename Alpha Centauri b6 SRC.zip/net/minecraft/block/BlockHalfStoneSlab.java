package net.minecraft.block;

import net.minecraft.block.BlockStoneSlab;

public class BlockHalfStoneSlab extends BlockStoneSlab {
   public boolean isDouble() {
      return false;
   }
}
