package net.minecraft.client.audio;

public interface ISoundEventAccessor {
   int getWeight();

   Object cloneEntry();
}
