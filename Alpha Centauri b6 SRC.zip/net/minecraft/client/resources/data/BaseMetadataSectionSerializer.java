package net.minecraft.client.resources.data;

import net.minecraft.client.resources.data.IMetadataSectionSerializer;

public abstract class BaseMetadataSectionSerializer implements IMetadataSectionSerializer {
}
