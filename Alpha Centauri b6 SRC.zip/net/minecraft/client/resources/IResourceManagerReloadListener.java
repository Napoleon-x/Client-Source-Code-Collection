package net.minecraft.client.resources;

import net.minecraft.client.resources.IResourceManager;

public interface IResourceManagerReloadListener {
   void onResourceManagerReload(IResourceManager var1);
}
