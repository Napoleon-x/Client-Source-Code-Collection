package net.minecraft.client.renderer.block.statemap;

import java.util.Map;
import net.minecraft.block.Block;

public interface IStateMapper {
   Map putStateModelLocations(Block var1);
}
