package net.minecraft.client.renderer;

import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.src.Config;
import org.lwjgl.opengl.ARBFramebufferObject;
import org.lwjgl.opengl.ARBMultitexture;
import org.lwjgl.opengl.ARBShaderObjects;
import org.lwjgl.opengl.ARBVertexBufferObject;
import org.lwjgl.opengl.ARBVertexShader;
import org.lwjgl.opengl.ContextCapabilities;
import org.lwjgl.opengl.EXTBlendFuncSeparate;
import org.lwjgl.opengl.EXTFramebufferObject;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GLContext;
import oshi.SystemInfo;
import oshi.hardware.Processor;

public class OpenGlHelper {
   public static boolean nvidia;
   public static boolean field_181063_b;
   public static int GL_FRAMEBUFFER;
   public static int GL_RENDERBUFFER;
   public static int GL_COLOR_ATTACHMENT0;
   public static int GL_DEPTH_ATTACHMENT;
   public static int GL_FRAMEBUFFER_COMPLETE;
   public static int GL_FB_INCOMPLETE_ATTACHMENT;
   public static int GL_FB_INCOMPLETE_MISS_ATTACH;
   public static int GL_FB_INCOMPLETE_DRAW_BUFFER;
   public static int GL_FB_INCOMPLETE_READ_BUFFER;
   private static int framebufferType;
   public static boolean framebufferSupported;
   private static boolean shadersAvailable;
   private static boolean arbShaders;
   public static int GL_LINK_STATUS;
   public static int GL_COMPILE_STATUS;
   public static int GL_VERTEX_SHADER;
   public static int GL_FRAGMENT_SHADER;
   private static boolean arbMultitexture;
   public static int defaultTexUnit;
   public static int lightmapTexUnit;
   public static int GL_TEXTURE2;
   private static boolean arbTextureEnvCombine;
   public static int GL_COMBINE;
   public static int GL_INTERPOLATE;
   public static int GL_PRIMARY_COLOR;
   public static int GL_CONSTANT;
   public static int GL_PREVIOUS;
   public static int GL_COMBINE_RGB;
   public static int GL_SOURCE0_RGB;
   public static int GL_SOURCE1_RGB;
   public static int GL_SOURCE2_RGB;
   public static int GL_OPERAND0_RGB;
   public static int GL_OPERAND1_RGB;
   public static int GL_OPERAND2_RGB;
   public static int GL_COMBINE_ALPHA;
   public static int GL_SOURCE0_ALPHA;
   public static int GL_SOURCE1_ALPHA;
   public static int GL_SOURCE2_ALPHA;
   public static int GL_OPERAND0_ALPHA;
   public static int GL_OPERAND1_ALPHA;
   public static int GL_OPERAND2_ALPHA;
   private static boolean openGL14;
   public static boolean extBlendFuncSeparate;
   public static boolean openGL21;
   public static boolean shadersSupported;
   private static String logText = "";
   private static String field_183030_aa;
   public static boolean vboSupported;
   public static boolean field_181062_Q;
   private static boolean arbVbo;
   public static int GL_ARRAY_BUFFER;
   public static int GL_STATIC_DRAW;
   private static final String __OBFID = "CL_00001179";
   public static float lastBrightnessX = 0.0F;
   public static float lastBrightnessY = 0.0F;

   public static void setActiveTexture(int texture) {
      if(arbMultitexture) {
         ARBMultitexture.glActiveTextureARB(texture);
      } else {
         GL13.glActiveTexture(texture);
      }

   }

   public static void initializeTextures() {
      Config.initDisplay();
      ContextCapabilities contextcapabilities = GLContext.getCapabilities();
      arbMultitexture = contextcapabilities.GL_ARB_multitexture && !contextcapabilities.OpenGL13;
      arbTextureEnvCombine = contextcapabilities.GL_ARB_texture_env_combine && !contextcapabilities.OpenGL13;
      if(arbMultitexture) {
         logText = logText + "Using ARB_multitexture.\n";
         defaultTexUnit = '蓀';
         lightmapTexUnit = '蓁';
         GL_TEXTURE2 = '蓂';
      } else {
         logText = logText + "Using GL 1.3 multitexturing.\n";
         defaultTexUnit = '蓀';
         lightmapTexUnit = '蓁';
         GL_TEXTURE2 = '蓂';
      }

      if(arbTextureEnvCombine) {
         logText = logText + "Using ARB_texture_env_combine.\n";
         GL_COMBINE = '蕰';
         GL_INTERPOLATE = '蕵';
         GL_PRIMARY_COLOR = '蕷';
         GL_CONSTANT = '蕶';
         GL_PREVIOUS = '蕸';
         GL_COMBINE_RGB = '蕱';
         GL_SOURCE0_RGB = '薀';
         GL_SOURCE1_RGB = '薁';
         GL_SOURCE2_RGB = '薂';
         GL_OPERAND0_RGB = '薐';
         GL_OPERAND1_RGB = '薑';
         GL_OPERAND2_RGB = '薒';
         GL_COMBINE_ALPHA = '蕲';
         GL_SOURCE0_ALPHA = '薈';
         GL_SOURCE1_ALPHA = '薉';
         GL_SOURCE2_ALPHA = '薊';
         GL_OPERAND0_ALPHA = '薘';
         GL_OPERAND1_ALPHA = '薙';
         GL_OPERAND2_ALPHA = '薚';
      } else {
         logText = logText + "Using GL 1.3 texture combiners.\n";
         GL_COMBINE = '蕰';
         GL_INTERPOLATE = '蕵';
         GL_PRIMARY_COLOR = '蕷';
         GL_CONSTANT = '蕶';
         GL_PREVIOUS = '蕸';
         GL_COMBINE_RGB = '蕱';
         GL_SOURCE0_RGB = '薀';
         GL_SOURCE1_RGB = '薁';
         GL_SOURCE2_RGB = '薂';
         GL_OPERAND0_RGB = '薐';
         GL_OPERAND1_RGB = '薑';
         GL_OPERAND2_RGB = '薒';
         GL_COMBINE_ALPHA = '蕲';
         GL_SOURCE0_ALPHA = '薈';
         GL_SOURCE1_ALPHA = '薉';
         GL_SOURCE2_ALPHA = '薊';
         GL_OPERAND0_ALPHA = '薘';
         GL_OPERAND1_ALPHA = '薙';
         GL_OPERAND2_ALPHA = '薚';
      }

      extBlendFuncSeparate = contextcapabilities.GL_EXT_blend_func_separate && !contextcapabilities.OpenGL14;
      openGL14 = contextcapabilities.OpenGL14 || contextcapabilities.GL_EXT_blend_func_separate;
      framebufferSupported = openGL14 && (contextcapabilities.GL_ARB_framebuffer_object || contextcapabilities.GL_EXT_framebuffer_object || contextcapabilities.OpenGL30);
      if(framebufferSupported) {
         logText = logText + "Using framebuffer objects because ";
         if(contextcapabilities.OpenGL30) {
            logText = logText + "OpenGL 3.0 is supported and separate blending is supported.\n";
            framebufferType = 0;
            GL_FRAMEBUFFER = '赀';
            GL_RENDERBUFFER = '赁';
            GL_COLOR_ATTACHMENT0 = '賠';
            GL_DEPTH_ATTACHMENT = '贀';
            GL_FRAMEBUFFER_COMPLETE = '賕';
            GL_FB_INCOMPLETE_ATTACHMENT = '賖';
            GL_FB_INCOMPLETE_MISS_ATTACH = '賗';
            GL_FB_INCOMPLETE_DRAW_BUFFER = '賛';
            GL_FB_INCOMPLETE_READ_BUFFER = '賜';
         } else if(contextcapabilities.GL_ARB_framebuffer_object) {
            logText = logText + "ARB_framebuffer_object is supported and separate blending is supported.\n";
            framebufferType = 1;
            GL_FRAMEBUFFER = '赀';
            GL_RENDERBUFFER = '赁';
            GL_COLOR_ATTACHMENT0 = '賠';
            GL_DEPTH_ATTACHMENT = '贀';
            GL_FRAMEBUFFER_COMPLETE = '賕';
            GL_FB_INCOMPLETE_MISS_ATTACH = '賗';
            GL_FB_INCOMPLETE_ATTACHMENT = '賖';
            GL_FB_INCOMPLETE_DRAW_BUFFER = '賛';
            GL_FB_INCOMPLETE_READ_BUFFER = '賜';
         } else if(contextcapabilities.GL_EXT_framebuffer_object) {
            logText = logText + "EXT_framebuffer_object is supported.\n";
            framebufferType = 2;
            GL_FRAMEBUFFER = '赀';
            GL_RENDERBUFFER = '赁';
            GL_COLOR_ATTACHMENT0 = '賠';
            GL_DEPTH_ATTACHMENT = '贀';
            GL_FRAMEBUFFER_COMPLETE = '賕';
            GL_FB_INCOMPLETE_MISS_ATTACH = '賗';
            GL_FB_INCOMPLETE_ATTACHMENT = '賖';
            GL_FB_INCOMPLETE_DRAW_BUFFER = '賛';
            GL_FB_INCOMPLETE_READ_BUFFER = '賜';
         }
      } else {
         logText = logText + "Not using framebuffer objects because ";
         logText = logText + "OpenGL 1.4 is " + (contextcapabilities.OpenGL14?"":"not ") + "supported, ";
         logText = logText + "EXT_blend_func_separate is " + (contextcapabilities.GL_EXT_blend_func_separate?"":"not ") + "supported, ";
         logText = logText + "OpenGL 3.0 is " + (contextcapabilities.OpenGL30?"":"not ") + "supported, ";
         logText = logText + "ARB_framebuffer_object is " + (contextcapabilities.GL_ARB_framebuffer_object?"":"not ") + "supported, and ";
         logText = logText + "EXT_framebuffer_object is " + (contextcapabilities.GL_EXT_framebuffer_object?"":"not ") + "supported.\n";
      }

      openGL21 = contextcapabilities.OpenGL21;
      shadersAvailable = openGL21 || contextcapabilities.GL_ARB_vertex_shader && contextcapabilities.GL_ARB_fragment_shader && contextcapabilities.GL_ARB_shader_objects;
      logText = logText + "Shaders are " + (shadersAvailable?"":"not ") + "available because ";
      if(shadersAvailable) {
         if(contextcapabilities.OpenGL21) {
            logText = logText + "OpenGL 2.1 is supported.\n";
            arbShaders = false;
            GL_LINK_STATUS = '讂';
            GL_COMPILE_STATUS = '讁';
            GL_VERTEX_SHADER = '謱';
            GL_FRAGMENT_SHADER = '謰';
         } else {
            logText = logText + "ARB_shader_objects, ARB_vertex_shader, and ARB_fragment_shader are supported.\n";
            arbShaders = true;
            GL_LINK_STATUS = '讂';
            GL_COMPILE_STATUS = '讁';
            GL_VERTEX_SHADER = '謱';
            GL_FRAGMENT_SHADER = '謰';
         }
      } else {
         logText = logText + "OpenGL 2.1 is " + (contextcapabilities.OpenGL21?"":"not ") + "supported, ";
         logText = logText + "ARB_shader_objects is " + (contextcapabilities.GL_ARB_shader_objects?"":"not ") + "supported, ";
         logText = logText + "ARB_vertex_shader is " + (contextcapabilities.GL_ARB_vertex_shader?"":"not ") + "supported, and ";
         logText = logText + "ARB_fragment_shader is " + (contextcapabilities.GL_ARB_fragment_shader?"":"not ") + "supported.\n";
      }

      shadersSupported = framebufferSupported && shadersAvailable;
      String s = GL11.glGetString(7936).toLowerCase();
      nvidia = s.contains("nvidia");
      arbVbo = !contextcapabilities.OpenGL15 && contextcapabilities.GL_ARB_vertex_buffer_object;
      vboSupported = contextcapabilities.OpenGL15 || arbVbo;
      logText = logText + "VBOs are " + (vboSupported?"":"not ") + "available because ";
      if(vboSupported) {
         if(arbVbo) {
            logText = logText + "ARB_vertex_buffer_object is supported.\n";
            GL_STATIC_DRAW = '裤';
            GL_ARRAY_BUFFER = '袒';
         } else {
            logText = logText + "OpenGL 1.5 is supported.\n";
            GL_STATIC_DRAW = '裤';
            GL_ARRAY_BUFFER = '袒';
         }
      }

      field_181063_b = s.contains("ati");
      if(field_181063_b) {
         if(vboSupported) {
            field_181062_Q = true;
         } else {
            GameSettings.Options.RENDER_DISTANCE.setValueMax(16.0F);
         }
      }

      try {
         Processor[] aprocessor = (new SystemInfo()).getHardware().getProcessors();
         field_183030_aa = String.format("%dx %s", new Object[]{Integer.valueOf(aprocessor.length), aprocessor[0]}).replaceAll("\\s+", " ");
      } catch (Throwable var3) {
         ;
      }

   }

   public static int glGetShaderi(int shaderIn, int pname) {
      return arbShaders?ARBShaderObjects.glGetObjectParameteriARB(shaderIn, pname):GL20.glGetShaderi(shaderIn, pname);
   }

   public static String getLogText() {
      return logText;
   }

   public static void glUniform1(int location, FloatBuffer values) {
      if(arbShaders) {
         ARBShaderObjects.glUniform1ARB(location, values);
      } else {
         GL20.glUniform1(location, values);
      }

   }

   public static void glUniform1(int location, IntBuffer values) {
      if(arbShaders) {
         ARBShaderObjects.glUniform1ARB(location, values);
      } else {
         GL20.glUniform1(location, values);
      }

   }

   public static void glUniform3(int location, IntBuffer values) {
      if(arbShaders) {
         ARBShaderObjects.glUniform3ARB(location, values);
      } else {
         GL20.glUniform3(location, values);
      }

   }

   public static void glUniform3(int location, FloatBuffer values) {
      if(arbShaders) {
         ARBShaderObjects.glUniform3ARB(location, values);
      } else {
         GL20.glUniform3(location, values);
      }

   }

   public static void glUniform4(int location, FloatBuffer values) {
      if(arbShaders) {
         ARBShaderObjects.glUniform4ARB(location, values);
      } else {
         GL20.glUniform4(location, values);
      }

   }

   public static void glUniform4(int location, IntBuffer values) {
      if(arbShaders) {
         ARBShaderObjects.glUniform4ARB(location, values);
      } else {
         GL20.glUniform4(location, values);
      }

   }

   public static void glUniformMatrix2(int location, boolean transpose, FloatBuffer matrices) {
      if(arbShaders) {
         ARBShaderObjects.glUniformMatrix2ARB(location, transpose, matrices);
      } else {
         GL20.glUniformMatrix2(location, transpose, matrices);
      }

   }

   public static void glUniform2(int location, IntBuffer values) {
      if(arbShaders) {
         ARBShaderObjects.glUniform2ARB(location, values);
      } else {
         GL20.glUniform2(location, values);
      }

   }

   public static void glUniform2(int location, FloatBuffer values) {
      if(arbShaders) {
         ARBShaderObjects.glUniform2ARB(location, values);
      } else {
         GL20.glUniform2(location, values);
      }

   }

   public static void glUniformMatrix3(int location, boolean transpose, FloatBuffer matrices) {
      if(arbShaders) {
         ARBShaderObjects.glUniformMatrix3ARB(location, transpose, matrices);
      } else {
         GL20.glUniformMatrix3(location, transpose, matrices);
      }

   }

   public static int glGetProgrami(int program, int pname) {
      return arbShaders?ARBShaderObjects.glGetObjectParameteriARB(program, pname):GL20.glGetProgrami(program, pname);
   }

   public static void glUniformMatrix4(int location, boolean transpose, FloatBuffer matrices) {
      if(arbShaders) {
         ARBShaderObjects.glUniformMatrix4ARB(location, transpose, matrices);
      } else {
         GL20.glUniformMatrix4(location, transpose, matrices);
      }

   }

   public static void setLightmapTextureCoords(int target, float p_77475_1_, float p_77475_2_) {
      if(arbMultitexture) {
         ARBMultitexture.glMultiTexCoord2fARB(target, p_77475_1_, p_77475_2_);
      } else {
         GL13.glMultiTexCoord2f(target, p_77475_1_, p_77475_2_);
      }

      if(target == lightmapTexUnit) {
         lastBrightnessX = p_77475_1_;
         lastBrightnessY = p_77475_2_;
      }

   }

   public static boolean useVbo() {
      return Config.isMultiTexture()?false:vboSupported && Minecraft.getMinecraft().gameSettings.useVbo;
   }

   public static boolean areShadersSupported() {
      return shadersSupported;
   }

   public static String glGetProgramInfoLog(int program, int maxLength) {
      return arbShaders?ARBShaderObjects.glGetInfoLogARB(program, maxLength):GL20.glGetProgramInfoLog(program, maxLength);
   }

   public static int glGetUniformLocation(int programObj, CharSequence name) {
      return arbShaders?ARBShaderObjects.glGetUniformLocationARB(programObj, name):GL20.glGetUniformLocation(programObj, name);
   }

   public static String glGetShaderInfoLog(int shaderIn, int maxLength) {
      return arbShaders?ARBShaderObjects.glGetInfoLogARB(shaderIn, maxLength):GL20.glGetShaderInfoLog(shaderIn, maxLength);
   }

   public static int glGetAttribLocation(int p_153164_0_, CharSequence p_153164_1_) {
      return arbShaders?ARBVertexShader.glGetAttribLocationARB(p_153164_0_, p_153164_1_):GL20.glGetAttribLocation(p_153164_0_, p_153164_1_);
   }

   public static int glCheckFramebufferStatus(int target) {
      if(!framebufferSupported) {
         return -1;
      } else {
         switch(framebufferType) {
         case 0:
            return GL30.glCheckFramebufferStatus(target);
         case 1:
            return ARBFramebufferObject.glCheckFramebufferStatus(target);
         case 2:
            return EXTFramebufferObject.glCheckFramebufferStatusEXT(target);
         default:
            return -1;
         }
      }
   }

   public static void glBindRenderbuffer(int target, int renderbuffer) {
      if(framebufferSupported) {
         switch(framebufferType) {
         case 0:
            GL30.glBindRenderbuffer(target, renderbuffer);
            break;
         case 1:
            ARBFramebufferObject.glBindRenderbuffer(target, renderbuffer);
            break;
         case 2:
            EXTFramebufferObject.glBindRenderbufferEXT(target, renderbuffer);
         }
      }

   }

   public static void glRenderbufferStorage(int target, int internalFormat, int width, int height) {
      if(framebufferSupported) {
         switch(framebufferType) {
         case 0:
            GL30.glRenderbufferStorage(target, internalFormat, width, height);
            break;
         case 1:
            ARBFramebufferObject.glRenderbufferStorage(target, internalFormat, width, height);
            break;
         case 2:
            EXTFramebufferObject.glRenderbufferStorageEXT(target, internalFormat, width, height);
         }
      }

   }

   public static void glDeleteRenderbuffers(int renderbuffer) {
      if(framebufferSupported) {
         switch(framebufferType) {
         case 0:
            GL30.glDeleteRenderbuffers(renderbuffer);
            break;
         case 1:
            ARBFramebufferObject.glDeleteRenderbuffers(renderbuffer);
            break;
         case 2:
            EXTFramebufferObject.glDeleteRenderbuffersEXT(renderbuffer);
         }
      }

   }

   public static void glFramebufferTexture2D(int target, int attachment, int textarget, int texture, int level) {
      if(framebufferSupported) {
         switch(framebufferType) {
         case 0:
            GL30.glFramebufferTexture2D(target, attachment, textarget, texture, level);
            break;
         case 1:
            ARBFramebufferObject.glFramebufferTexture2D(target, attachment, textarget, texture, level);
            break;
         case 2:
            EXTFramebufferObject.glFramebufferTexture2DEXT(target, attachment, textarget, texture, level);
         }
      }

   }

   public static int glGenRenderbuffers() {
      if(!framebufferSupported) {
         return -1;
      } else {
         switch(framebufferType) {
         case 0:
            return GL30.glGenRenderbuffers();
         case 1:
            return ARBFramebufferObject.glGenRenderbuffers();
         case 2:
            return EXTFramebufferObject.glGenRenderbuffersEXT();
         default:
            return -1;
         }
      }
   }

   public static int glGenFramebuffers() {
      if(!framebufferSupported) {
         return -1;
      } else {
         switch(framebufferType) {
         case 0:
            return GL30.glGenFramebuffers();
         case 1:
            return ARBFramebufferObject.glGenFramebuffers();
         case 2:
            return EXTFramebufferObject.glGenFramebuffersEXT();
         default:
            return -1;
         }
      }
   }

   public static void glDeleteFramebuffers(int framebufferIn) {
      if(framebufferSupported) {
         switch(framebufferType) {
         case 0:
            GL30.glDeleteFramebuffers(framebufferIn);
            break;
         case 1:
            ARBFramebufferObject.glDeleteFramebuffers(framebufferIn);
            break;
         case 2:
            EXTFramebufferObject.glDeleteFramebuffersEXT(framebufferIn);
         }
      }

   }

   public static void glBindFramebuffer(int target, int framebufferIn) {
      if(framebufferSupported) {
         switch(framebufferType) {
         case 0:
            GL30.glBindFramebuffer(target, framebufferIn);
            break;
         case 1:
            ARBFramebufferObject.glBindFramebuffer(target, framebufferIn);
            break;
         case 2:
            EXTFramebufferObject.glBindFramebufferEXT(target, framebufferIn);
         }
      }

   }

   public static void glFramebufferRenderbuffer(int target, int attachment, int renderBufferTarget, int renderBuffer) {
      if(framebufferSupported) {
         switch(framebufferType) {
         case 0:
            GL30.glFramebufferRenderbuffer(target, attachment, renderBufferTarget, renderBuffer);
            break;
         case 1:
            ARBFramebufferObject.glFramebufferRenderbuffer(target, attachment, renderBufferTarget, renderBuffer);
            break;
         case 2:
            EXTFramebufferObject.glFramebufferRenderbufferEXT(target, attachment, renderBufferTarget, renderBuffer);
         }
      }

   }

   public static void glBindBuffer(int target, int buffer) {
      if(arbVbo) {
         ARBVertexBufferObject.glBindBufferARB(target, buffer);
      } else {
         GL15.glBindBuffer(target, buffer);
      }

   }

   public static void glDeleteBuffers(int buffer) {
      if(arbVbo) {
         ARBVertexBufferObject.glDeleteBuffersARB(buffer);
      } else {
         GL15.glDeleteBuffers(buffer);
      }

   }

   public static void glCompileShader(int shaderIn) {
      if(arbShaders) {
         ARBShaderObjects.glCompileShaderARB(shaderIn);
      } else {
         GL20.glCompileShader(shaderIn);
      }

   }

   public static int glGenBuffers() {
      return arbVbo?ARBVertexBufferObject.glGenBuffersARB():GL15.glGenBuffers();
   }

   public static int glCreateShader(int type) {
      return arbShaders?ARBShaderObjects.glCreateShaderObjectARB(type):GL20.glCreateShader(type);
   }

   public static void glDeleteProgram(int program) {
      if(arbShaders) {
         ARBShaderObjects.glDeleteObjectARB(program);
      } else {
         GL20.glDeleteProgram(program);
      }

   }

   public static void glDeleteShader(int p_153180_0_) {
      if(arbShaders) {
         ARBShaderObjects.glDeleteObjectARB(p_153180_0_);
      } else {
         GL20.glDeleteShader(p_153180_0_);
      }

   }

   public static int glCreateProgram() {
      return arbShaders?ARBShaderObjects.glCreateProgramObjectARB():GL20.glCreateProgram();
   }

   public static void glLinkProgram(int program) {
      if(arbShaders) {
         ARBShaderObjects.glLinkProgramARB(program);
      } else {
         GL20.glLinkProgram(program);
      }

   }

   public static void glUniform1i(int location, int v0) {
      if(arbShaders) {
         ARBShaderObjects.glUniform1iARB(location, v0);
      } else {
         GL20.glUniform1i(location, v0);
      }

   }

   public static void glShaderSource(int shaderIn, ByteBuffer string) {
      if(arbShaders) {
         ARBShaderObjects.glShaderSourceARB(shaderIn, string);
      } else {
         GL20.glShaderSource(shaderIn, string);
      }

   }

   public static void glAttachShader(int program, int shaderIn) {
      if(arbShaders) {
         ARBShaderObjects.glAttachObjectARB(program, shaderIn);
      } else {
         GL20.glAttachShader(program, shaderIn);
      }

   }

   public static void glBufferData(int target, ByteBuffer data, int usage) {
      if(arbVbo) {
         ARBVertexBufferObject.glBufferDataARB(target, data, usage);
      } else {
         GL15.glBufferData(target, data, usage);
      }

   }

   public static void glUseProgram(int program) {
      if(arbShaders) {
         ARBShaderObjects.glUseProgramObjectARB(program);
      } else {
         GL20.glUseProgram(program);
      }

   }

   public static void glBlendFunc(int sFactorRGB, int dFactorRGB, int sfactorAlpha, int dfactorAlpha) {
      if(openGL14) {
         if(extBlendFuncSeparate) {
            EXTBlendFuncSeparate.glBlendFuncSeparateEXT(sFactorRGB, dFactorRGB, sfactorAlpha, dfactorAlpha);
         } else {
            GL14.glBlendFuncSeparate(sFactorRGB, dFactorRGB, sfactorAlpha, dfactorAlpha);
         }
      } else {
         GL11.glBlendFunc(sFactorRGB, dFactorRGB);
      }

   }

   public static boolean isFramebufferEnabled() {
      return Config.isFastRender()?false:(Config.isAntialiasing()?false:framebufferSupported && Minecraft.getMinecraft().gameSettings.fboEnable);
   }

   public static void setClientActiveTexture(int texture) {
      if(arbMultitexture) {
         ARBMultitexture.glClientActiveTextureARB(texture);
      } else {
         GL13.glClientActiveTexture(texture);
      }

   }

   public static String func_183029_j() {
      return field_183030_aa == null?"<unknown>":field_183030_aa;
   }
}
