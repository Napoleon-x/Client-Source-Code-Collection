package net.minecraft.client.renderer.texture;

import net.minecraft.client.renderer.texture.TextureMap;

public interface IIconCreator {
   void registerSprites(TextureMap var1);
}
