package rina.turok.turok.values;

public class TurokEnum {
   Class value;

   public TurokEnum(Class turok_enum) {
      this.value = turok_enum;
   }
}
