package rina.turok.bope.bopemod;

public class BopeFriend {
   String name;

   public BopeFriend(String name) {
      this.name = name;
   }

   public String get_name() {
      return this.name;
   }
}
