package rina.turok.bope.mixins;

import net.minecraft.client.multiplayer.PlayerControllerMP;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({PlayerControllerMP.class})
public class BopeMixinPlayerControllerMP {
}
