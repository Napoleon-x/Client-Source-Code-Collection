/*
 * Decompiled with CFR 0_118.
 */
package net.minecraft.block;

import net.minecraft.block.BlockStoneSlabNew;

public class BlockDoubleStoneSlabNew
extends BlockStoneSlabNew {
    private static final String __OBFID = "CL_00002114";

    @Override
    public boolean isDouble() {
        return true;
    }
}

