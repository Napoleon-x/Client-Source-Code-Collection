/*
 * Decompiled with CFR 0_118.
 */
package net.minecraft.block;

import net.minecraft.block.BlockStoneSlab;

public class BlockDoubleStoneSlab
extends BlockStoneSlab {
    private static final String __OBFID = "CL_00002113";

    @Override
    public boolean isDouble() {
        return true;
    }
}

