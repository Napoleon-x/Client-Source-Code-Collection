/*
 * Decompiled with CFR 0_118.
 */
package net.minecraft.block;

import net.minecraft.block.BlockWoodSlab;

public class BlockHalfWoodSlab
extends BlockWoodSlab {
    private static final String __OBFID = "CL_00002107";

    @Override
    public boolean isDouble() {
        return false;
    }
}

