/*
 * Decompiled with CFR 0_118.
 */
package net.minecraft.block;

import net.minecraft.block.BlockFlower;

public class BlockYellowFlower
extends BlockFlower {
    private static final String __OBFID = "CL_00002045";

    @Override
    public BlockFlower.EnumFlowerColor func_176495_j() {
        return BlockFlower.EnumFlowerColor.YELLOW;
    }
}

