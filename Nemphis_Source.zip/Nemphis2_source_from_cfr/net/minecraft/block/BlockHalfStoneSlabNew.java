/*
 * Decompiled with CFR 0_118.
 */
package net.minecraft.block;

import net.minecraft.block.BlockStoneSlabNew;

public class BlockHalfStoneSlabNew
extends BlockStoneSlabNew {
    private static final String __OBFID = "CL_00002110";

    @Override
    public boolean isDouble() {
        return false;
    }
}

