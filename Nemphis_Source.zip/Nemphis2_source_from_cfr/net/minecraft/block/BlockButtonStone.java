/*
 * Decompiled with CFR 0_118.
 */
package net.minecraft.block;

import net.minecraft.block.BlockButton;

public class BlockButtonStone
extends BlockButton {
    private static final String __OBFID = "CL_00000319";

    protected BlockButtonStone() {
        super(false);
    }
}

