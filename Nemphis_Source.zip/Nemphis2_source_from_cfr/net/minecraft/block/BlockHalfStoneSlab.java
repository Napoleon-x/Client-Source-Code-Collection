/*
 * Decompiled with CFR 0_118.
 */
package net.minecraft.block;

import net.minecraft.block.BlockStoneSlab;

public class BlockHalfStoneSlab
extends BlockStoneSlab {
    private static final String __OBFID = "CL_00002108";

    @Override
    public boolean isDouble() {
        return false;
    }
}

