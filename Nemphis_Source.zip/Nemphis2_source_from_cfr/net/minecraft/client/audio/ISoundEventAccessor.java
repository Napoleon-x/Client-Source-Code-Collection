/*
 * Decompiled with CFR 0_118.
 */
package net.minecraft.client.audio;

public interface ISoundEventAccessor {
    public int getWeight();

    public Object cloneEntry();
}

