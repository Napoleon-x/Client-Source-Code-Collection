/*
 * Decompiled with CFR 0_118.
 */
package net.minecraft.client.gui;

public interface GuiYesNoCallback {
    public void confirmClicked(boolean var1, int var2);
}

