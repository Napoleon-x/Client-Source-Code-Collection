/*
 * Decompiled with CFR 0_118.
 */
package net.minecraft.client.gui.spectator;

import net.minecraft.client.gui.spectator.SpectatorMenu;

public interface ISpectatorMenuReciepient {
    public void func_175257_a(SpectatorMenu var1);
}

