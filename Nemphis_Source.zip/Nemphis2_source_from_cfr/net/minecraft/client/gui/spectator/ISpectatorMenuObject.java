/*
 * Decompiled with CFR 0_118.
 */
package net.minecraft.client.gui.spectator;

import net.minecraft.client.gui.spectator.SpectatorMenu;
import net.minecraft.util.IChatComponent;

public interface ISpectatorMenuObject {
    public void func_178661_a(SpectatorMenu var1);

    public IChatComponent func_178664_z_();

    public void func_178663_a(float var1, int var2);

    public boolean func_178662_A_();
}

