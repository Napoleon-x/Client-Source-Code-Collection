/*
 * Decompiled with CFR 0_118.
 */
package net.minecraft.client.gui.spectator;

import java.util.List;
import net.minecraft.util.IChatComponent;

public interface ISpectatorMenuView {
    public List func_178669_a();

    public IChatComponent func_178670_b();
}

