/*
 * Decompiled with CFR 0_118.
 */
package net.minecraftforge.client.model;

public interface IModelPart {
}

