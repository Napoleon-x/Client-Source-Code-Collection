/*
 * Decompiled with CFR 0_118.
 */
package net.minecraftforge.client.model.pipeline;

import net.minecraftforge.client.model.pipeline.IVertexConsumer;

public interface IVertexProducer {
    public void pipe(IVertexConsumer var1);
}

