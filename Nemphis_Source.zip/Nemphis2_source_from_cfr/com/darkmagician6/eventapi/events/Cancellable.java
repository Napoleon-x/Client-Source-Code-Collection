/*
 * Decompiled with CFR 0_118.
 */
package com.darkmagician6.eventapi.events;

public interface Cancellable {
    public boolean isCancelled();

    public void setCancelled(boolean var1);
}

