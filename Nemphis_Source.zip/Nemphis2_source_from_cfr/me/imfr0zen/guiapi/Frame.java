/*
 * Decompiled with CFR 0_118.
 */
package me.imfr0zen.guiapi;

public interface Frame {
    public void init();

    public void render(int var1, int var2);

    public void mouseClicked(int var1, int var2, int var3);

    public void keyTyped(int var1, char var2);
}

