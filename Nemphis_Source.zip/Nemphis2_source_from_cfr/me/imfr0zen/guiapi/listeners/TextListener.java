/*
 * Decompiled with CFR 0_118.
 */
package me.imfr0zen.guiapi.listeners;

public interface TextListener {
    public void keyTyped(char var1, String var2);

    public void stringEntered(String var1);
}

