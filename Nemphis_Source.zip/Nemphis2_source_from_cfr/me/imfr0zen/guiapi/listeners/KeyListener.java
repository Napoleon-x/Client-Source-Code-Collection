/*
 * Decompiled with CFR 0_118.
 */
package me.imfr0zen.guiapi.listeners;

public interface KeyListener {
    public void keyChanged(int var1);
}

