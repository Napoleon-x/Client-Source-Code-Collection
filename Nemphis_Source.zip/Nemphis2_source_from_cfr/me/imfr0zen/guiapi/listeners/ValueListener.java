/*
 * Decompiled with CFR 0_118.
 */
package me.imfr0zen.guiapi.listeners;

public interface ValueListener {
    public void valueUpdated(float var1);

    public void valueChanged(float var1);
}

