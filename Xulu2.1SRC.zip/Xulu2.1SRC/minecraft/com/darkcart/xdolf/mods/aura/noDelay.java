package com.darkcart.xdolf.mods.aura;

import org.lwjgl.input.Keyboard;

import com.darkcart.xdolf.Module;
import com.darkcart.xdolf.util.Category;

public class noDelay extends Module {
	
	/**
	 * In ItemSword class
	 */
	
	public noDelay() {
		super("noSwordDelay", "New", "A Vanilla Anti-Sword Delay.", Keyboard.KEYBOARD_SIZE, 0xFFFFFF, Category.COMBAT);
	}}
