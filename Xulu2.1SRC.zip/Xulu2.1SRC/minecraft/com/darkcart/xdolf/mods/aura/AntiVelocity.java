package com.darkcart.xdolf.mods.aura;

import org.lwjgl.input.Keyboard;

import com.darkcart.xdolf.Module;
import com.darkcart.xdolf.util.Category;

public class AntiVelocity extends Module {
	
	
	public AntiVelocity() {
		super("antiVelocity", "New", "Blocks Knockback [Velocity].", Keyboard.KEY_NONE, 0xFFFFFF, Category.COMBAT);
}}
