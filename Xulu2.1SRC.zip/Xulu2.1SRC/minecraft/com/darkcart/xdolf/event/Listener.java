package com.darkcart.xdolf.event;

import java.util.EventListener;

public interface Listener extends EventListener
{
	
}