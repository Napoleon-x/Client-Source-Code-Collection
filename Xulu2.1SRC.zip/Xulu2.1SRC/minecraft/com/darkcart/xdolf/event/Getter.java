package com.darkcart.xdolf.event;

public @interface Getter {

}
