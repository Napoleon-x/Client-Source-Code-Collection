package com.darkcart.xdolf.event;


public abstract interface Event {}
