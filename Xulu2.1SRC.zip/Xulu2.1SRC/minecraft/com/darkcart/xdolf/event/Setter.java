package com.darkcart.xdolf.event;

public @interface Setter {

}
