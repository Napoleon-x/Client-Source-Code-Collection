package com.darkcart.xdolf.util;

public enum Category
{
	MOVEMENT,
	PLAYER,
	WORLD,
	RENDER,
	COMBAT,
	NONE,
}