package com.darkmagician6.eventapi;































public final class EventAPI
{
  public static final String VERSION = String.format("%s-%s", new Object[] { "0.7", "beta" });
  



  public static final String[] AUTHORS = {
    "DarkMagician6" };
  
  private EventAPI() {}
}
