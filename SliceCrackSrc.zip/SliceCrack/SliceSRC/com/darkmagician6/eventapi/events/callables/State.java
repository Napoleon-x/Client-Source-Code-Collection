package com.darkmagician6.eventapi.events.callables;

public enum State
{
  PRE,  POST;
}
