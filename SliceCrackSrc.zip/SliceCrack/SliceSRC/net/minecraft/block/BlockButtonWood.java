package net.minecraft.block;

public class BlockButtonWood extends BlockButton
{
  private static final String __OBFID = "CL_00000336";
  
  protected BlockButtonWood()
  {
    super(true);
  }
}
