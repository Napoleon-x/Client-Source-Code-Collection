package net.minecraft.client.model;


public class TextureOffset
{
  public final int textureOffsetX;
  
  public final int textureOffsetY;
  
  private static final String __OBFID = "CL_00000875";
  
  public TextureOffset(int p_i1175_1_, int p_i1175_2_)
  {
    textureOffsetX = p_i1175_1_;
    textureOffsetY = p_i1175_2_;
  }
}
