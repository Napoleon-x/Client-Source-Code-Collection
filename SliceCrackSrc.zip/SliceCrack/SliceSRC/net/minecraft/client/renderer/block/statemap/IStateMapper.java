package net.minecraft.client.renderer.block.statemap;

import java.util.Map;
import net.minecraft.block.Block;

public abstract interface IStateMapper
{
  public abstract Map func_178130_a(Block paramBlock);
}
