# XIV
A Minecraft client based around organization and user friendliness.  
## Getting Started
If you don't want to contribute to the project, [read the wiki](https://gitlab.com/latematt/XIV/wikis/home)  
If you know Java and would like to contribute, contact latematt on getting started with your favorite IDE.
## Licensing Information
The license used is called ["No License"](http://choosealicense.com/licenses/no-license/), modified to our needs.  
Users can modify the source (and contribute their modifications if wanted) freely, however under no circumstance should users distribute the source code and/or a build they compile from source.