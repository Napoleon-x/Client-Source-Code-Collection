package net.minecraft.block;

public class BlockYellowFlower extends BlockFlower
{


    public BlockFlower.EnumFlowerColor func_176495_j()
    {
        return BlockFlower.EnumFlowerColor.YELLOW;
    }
}
