/*
 * Decompiled with CFR 0_115.
 */
package cow.milkgod.cheese.files.files.modulefiles;

import cow.milkgod.cheese.files.FileManager;
import java.io.IOException;

public class Waypoints
extends FileManager.CustomFile {
    public Waypoints(String name, boolean Module2, boolean loadOnStart) {
        super(name, Module2, loadOnStart);
    }

    @Override
    public void loadFile() throws IOException {
        throw new Error("Unresolved compilation problems: \n\tWayPoints cannot be resolved\n\tWayPoints cannot be resolved to a type\n");
    }

    @Override
    public void saveFile() throws IOException {
        throw new Error("Unresolved compilation problems: \n\tWayPoints cannot be resolved to a type\n\tWayPoints cannot be resolved to a variable\n");
    }
}

