package cow.milkgod.cheese.files.files;

import cow.milkgod.cheese.files.*;
import cow.milkgod.cheese.files.FileManager.CustomFile;

import java.io.*;

public class Claimfinder extends FileManager.CustomFile {


	   public Claimfinder(String name, boolean Module, boolean loadOnStart) {
		super(name, Module, loadOnStart);
	      throw new Error("Unresolved compilation problems: \n\tThe declared package \"sallos.files\" does not match the expected package \"cow.milkgod.cheese.files.files\"\n\tClaimFinder cannot be resolved to a type\n\tClaimFinder cannot be resolved to a type\n\tThe method getModule(Class<? extends Module>) in the type ModuleManager is not applicable for the arguments (Class<ClaimFinder>)\n\tClaimFinder cannot be resolved to a type\n");
	}

	public void loadFile() throws IOException {
	      throw new Error("Unresolved compilation problem: \n");
	   }

	   public void saveFile() throws IOException {
	      throw new Error("Unresolved compilation problems: \n\tClaimFinder cannot be resolved to a type\n\tClaimFinder cannot be resolved to a type\n\tThe method getModule(Class<? extends Module>) in the type ModuleManager is not applicable for the arguments (Class<ClaimFinder>)\n\tClaimFinder cannot be resolved to a type\n");
	   }
	}
