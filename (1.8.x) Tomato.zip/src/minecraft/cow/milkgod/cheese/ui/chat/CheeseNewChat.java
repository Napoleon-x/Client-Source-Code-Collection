/*
 * Decompiled with CFR 0_115.
 */
package cow.milkgod.cheese.ui.chat;

public class CheeseNewChat {
}

