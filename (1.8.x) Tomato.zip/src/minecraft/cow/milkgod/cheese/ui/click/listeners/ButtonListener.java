/*
 * Decompiled with CFR 0_115.
 */
package cow.milkgod.cheese.ui.click.listeners;

public interface ButtonListener {
    public void buttonPress();
}

