/*
 * Decompiled with CFR 0_115.
 */
package cow.milkgod.cheese.events;

import com.darkmagician6.eventapi.events.Event;

public class MouseEvent
implements Event {
    public int key;

    public MouseEvent(int key) {
        this.key = key;
    }
}

