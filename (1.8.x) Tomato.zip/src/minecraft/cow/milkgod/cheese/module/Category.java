/*
 * Decompiled with CFR 0_115.
 */
package cow.milkgod.cheese.module;

public enum Category
{
    COMBAT("COMBAT", 0), 
    PLAYER("PLAYER", 1), 
    RENDER("RENDER", 2), 
    MOVEMENT("MOVEMENT", 3), 
    EXPLOITS("EXPLOITS", 4), 
    NONE("NONE", 5);
    
    private Category(final String s, final int n) {
    }
}

