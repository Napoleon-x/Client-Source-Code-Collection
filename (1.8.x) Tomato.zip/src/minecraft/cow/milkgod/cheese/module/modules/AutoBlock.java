/*
 * Decompiled with CFR 0_115.
 */
package cow.milkgod.cheese.module.modules;

import cow.milkgod.cheese.module.Category;
import cow.milkgod.cheese.module.Module;

public class AutoBlock
extends Module {
    public AutoBlock(String name, int bind, Category category, int colour, boolean visible, String description, String[] alias) {
        super(name, bind, category, colour, visible, description, alias);
    }

    @Override
    public void onEnable() {
    }
}

