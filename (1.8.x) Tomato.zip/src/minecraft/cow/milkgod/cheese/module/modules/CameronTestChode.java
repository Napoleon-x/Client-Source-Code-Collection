/*
 * Decompiled with CFR 0_115.
 */
package cow.milkgod.cheese.module.modules;

public class CameronTestChode {
}

