/*
 * Decompiled with CFR 0_115.
 */
package cow.milkgod.cheese.module.modules;

import cow.milkgod.cheese.module.Category;
import cow.milkgod.cheese.module.Module;

public class FreeView
extends Module {
    public FreeView() {
        super("FreeView", 0, Category.RENDER, 0, true, "FreeView bitches", new String[]{"fv"});
    }
}

