package me.zane.basicbus.api.bus;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import me.zane.basicbus.api.annotations.Listener;
import me.zane.basicbus.api.invocation.Invoker;

public interface Bus {
   Invoker invoker();

   Map map();

   default void subscribe(Object subscriber) {
      Method[] methods = subscriber.getClass().getDeclaredMethods();
      Map eventClassMethodMapRef = this.map();

      for(int i = methods.length - 1; i >= 0; --i) {
         Method method = methods[i];
         Listener listener = (Listener)method.getAnnotation(Listener.class);
         if (listener != null) {
            Class[] params = method.getParameterTypes();
            int paramsLength = params.length;
            if (paramsLength <= 1) {
               Class eventClass = listener.value();
               if (paramsLength != 1 || eventClass == params[0]) {
                  CallLocation callLoc = new CallLocation(subscriber, method);
                  if (eventClassMethodMapRef.containsKey(eventClass)) {
                     ((List)eventClassMethodMapRef.get(eventClass)).add(callLoc);
                  } else {
                     eventClassMethodMapRef.put(eventClass, new CopyOnWriteArrayList(Arrays.asList(callLoc)));
                  }
               }
            }
         }
      }

   }

   default void unsubscribe(Object subscriber) {
      Collection callLocationsRef = this.map().values();
      Iterator var3 = callLocationsRef.iterator();

      while(var3.hasNext()) {
         List callLocations = (List)var3.next();
         Iterator var5 = callLocations.iterator();

         while(var5.hasNext()) {
            CallLocation callLocation = (CallLocation)var5.next();
            if (callLocation.subscriber == subscriber) {
               callLocations.remove(callLocation);
            }
         }
      }

   }

   default void post(Object event) {
      List callLocations = (List)this.map().get(event.getClass());
      if (callLocations != null) {
         Iterator var3 = callLocations.iterator();

         while(var3.hasNext()) {
            CallLocation callLocation = (CallLocation)var3.next();
            Method method = callLocation.method;
            Object sub = callLocation.subscriber;
            if (callLocation.noParams) {
               this.invoker().invoke(sub, method);
            } else {
               this.invoker().invoke(sub, method, event);
            }
         }
      }

   }
}
