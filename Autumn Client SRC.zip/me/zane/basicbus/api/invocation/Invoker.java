package me.zane.basicbus.api.invocation;

import java.lang.reflect.Method;

@FunctionalInterface
public interface Invoker {
   void invoke(Object var1, Method var2, Object... var3);
}
