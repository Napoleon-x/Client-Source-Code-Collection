package net.minecraft.block;

public class BlockDoubleStoneSlab extends BlockStoneSlab {
   public boolean isDouble() {
      return true;
   }
}
