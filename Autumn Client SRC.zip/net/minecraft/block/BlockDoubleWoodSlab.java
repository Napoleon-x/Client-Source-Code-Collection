package net.minecraft.block;

public class BlockDoubleWoodSlab extends BlockWoodSlab {
   public boolean isDouble() {
      return true;
   }
}
