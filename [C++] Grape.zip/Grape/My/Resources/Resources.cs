using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Xh0kO1ZCmA.My.Resources
{
	[CompilerGenerated]
	[DebuggerNonUserCode]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
	[HideModuleName]
	internal static class Resources
	{
		private static System.Resources.ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		internal static UnmanagedMemoryStream _single
		{
			get
			{
				return Xh0kO1ZCmA.My.Resources.Resources.ResourceManager.GetStream("_single", Xh0kO1ZCmA.My.Resources.Resources.resourceCulture);
			}
		}

		internal static Bitmap clicker2
		{
			get
			{
				return (Bitmap)RuntimeHelpers.GetObjectValue(Xh0kO1ZCmA.My.Resources.Resources.ResourceManager.GetObject("clicker2", Xh0kO1ZCmA.My.Resources.Resources.resourceCulture));
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Xh0kO1ZCmA.My.Resources.Resources.resourceCulture;
			}
			set
			{
				Xh0kO1ZCmA.My.Resources.Resources.resourceCulture = value;
			}
		}

		internal static UnmanagedMemoryStream g303
		{
			get
			{
				return Xh0kO1ZCmA.My.Resources.Resources.ResourceManager.GetStream("g303", Xh0kO1ZCmA.My.Resources.Resources.resourceCulture);
			}
		}

		internal static UnmanagedMemoryStream g3032
		{
			get
			{
				return Xh0kO1ZCmA.My.Resources.Resources.ResourceManager.GetStream("g3032", Xh0kO1ZCmA.My.Resources.Resources.resourceCulture);
			}
		}

		internal static UnmanagedMemoryStream g502
		{
			get
			{
				return Xh0kO1ZCmA.My.Resources.Resources.ResourceManager.GetStream("g502", Xh0kO1ZCmA.My.Resources.Resources.resourceCulture);
			}
		}

		internal static UnmanagedMemoryStream GPro
		{
			get
			{
				return Xh0kO1ZCmA.My.Resources.Resources.ResourceManager.GetStream("GPro", Xh0kO1ZCmA.My.Resources.Resources.resourceCulture);
			}
		}

		internal static UnmanagedMemoryStream hp
		{
			get
			{
				return Xh0kO1ZCmA.My.Resources.Resources.ResourceManager.GetStream("hp", Xh0kO1ZCmA.My.Resources.Resources.resourceCulture);
			}
		}

		internal static Bitmap icon
		{
			get
			{
				return (Bitmap)RuntimeHelpers.GetObjectValue(Xh0kO1ZCmA.My.Resources.Resources.ResourceManager.GetObject("icon", Xh0kO1ZCmA.My.Resources.Resources.resourceCulture));
			}
		}

		internal static UnmanagedMemoryStream microsoft
		{
			get
			{
				return Xh0kO1ZCmA.My.Resources.Resources.ResourceManager.GetStream("microsoft", Xh0kO1ZCmA.My.Resources.Resources.resourceCulture);
			}
		}

		internal static UnmanagedMemoryStream oldmouse
		{
			get
			{
				return Xh0kO1ZCmA.My.Resources.Resources.ResourceManager.GetStream("oldmouse", Xh0kO1ZCmA.My.Resources.Resources.resourceCulture);
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static System.Resources.ResourceManager ResourceManager
		{
			get
			{
				if (object.ReferenceEquals(Xh0kO1ZCmA.My.Resources.Resources.resourceMan, null))
				{
					Xh0kO1ZCmA.My.Resources.Resources.resourceMan = new System.Resources.ResourceManager("Xh0kO1ZCmA.Resources", typeof(Xh0kO1ZCmA.My.Resources.Resources).Assembly);
				}
				return Xh0kO1ZCmA.My.Resources.Resources.resourceMan;
			}
		}

		internal static UnmanagedMemoryStream shaya
		{
			get
			{
				return Xh0kO1ZCmA.My.Resources.Resources.ResourceManager.GetStream("shaya", Xh0kO1ZCmA.My.Resources.Resources.resourceCulture);
			}
		}

		internal static UnmanagedMemoryStream Single__1_
		{
			get
			{
				return Xh0kO1ZCmA.My.Resources.Resources.ResourceManager.GetStream("Single__1_", Xh0kO1ZCmA.My.Resources.Resources.resourceCulture);
			}
		}

		internal static UnmanagedMemoryStream stimpy
		{
			get
			{
				return Xh0kO1ZCmA.My.Resources.Resources.ResourceManager.GetStream("stimpy", Xh0kO1ZCmA.My.Resources.Resources.resourceCulture);
			}
		}

		internal static UnmanagedMemoryStream test
		{
			get
			{
				return Xh0kO1ZCmA.My.Resources.Resources.ResourceManager.GetStream("test", Xh0kO1ZCmA.My.Resources.Resources.resourceCulture);
			}
		}

		internal static UnmanagedMemoryStream test2
		{
			get
			{
				return Xh0kO1ZCmA.My.Resources.Resources.ResourceManager.GetStream("test2", Xh0kO1ZCmA.My.Resources.Resources.resourceCulture);
			}
		}

		internal static UnmanagedMemoryStream Untitled
		{
			get
			{
				return Xh0kO1ZCmA.My.Resources.Resources.ResourceManager.GetStream("Untitled", Xh0kO1ZCmA.My.Resources.Resources.resourceCulture);
			}
		}
	}
}