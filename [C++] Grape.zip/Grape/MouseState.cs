using System;

namespace Xh0kO1ZCmA
{
	internal enum MouseState : byte
	{
		None,
		Over,
		Down,
		Block
	}
}