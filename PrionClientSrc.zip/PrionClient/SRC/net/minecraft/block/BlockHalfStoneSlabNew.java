package net.minecraft.block;

public class BlockHalfStoneSlabNew extends BlockStoneSlabNew {
  private static final String __OBFID = "CL_00002110";
  
  public BlockHalfStoneSlabNew() {}
  
  public boolean isDouble() {
    return false;
  }
}
