package net.minecraft.block;

import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityNote;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;

public class BlockNote extends BlockContainer
{
  private static final List field_176434_a = Lists.newArrayList(new String[] { "harp", "bd", "snare", "hat", "bassattack" });
  private static final String __OBFID = "CL_00000278";
  
  public BlockNote()
  {
    super(Material.wood);
    setCreativeTab(CreativeTabs.tabRedstone);
  }
  
  public void onNeighborBlockChange(World worldIn, BlockPos pos, IBlockState state, Block neighborBlock)
  {
    boolean var5 = worldIn.isBlockPowered(pos);
    TileEntity var6 = worldIn.getTileEntity(pos);
    
    if ((var6 instanceof TileEntityNote))
    {
      TileEntityNote var7 = (TileEntityNote)var6;
      
      if (previousRedstoneState != var5)
      {
        if (var5)
        {
          var7.func_175108_a(worldIn, pos);
        }
        
        previousRedstoneState = var5;
      }
    }
  }
  
  public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ)
  {
    if (isRemote)
    {
      return true;
    }
    

    TileEntity var9 = worldIn.getTileEntity(pos);
    
    if ((var9 instanceof TileEntityNote))
    {
      TileEntityNote var10 = (TileEntityNote)var9;
      var10.changePitch();
      var10.func_175108_a(worldIn, pos);
    }
    
    return true;
  }
  

  public void onBlockClicked(World worldIn, BlockPos pos, EntityPlayer playerIn)
  {
    if (!isRemote)
    {
      TileEntity var4 = worldIn.getTileEntity(pos);
      
      if ((var4 instanceof TileEntityNote))
      {
        ((TileEntityNote)var4).func_175108_a(worldIn, pos);
      }
    }
  }
  



  public TileEntity createNewTileEntity(World worldIn, int meta)
  {
    return new TileEntityNote();
  }
  
  private String func_176433_b(int p_176433_1_)
  {
    if ((p_176433_1_ < 0) || (p_176433_1_ >= field_176434_a.size()))
    {
      p_176433_1_ = 0;
    }
    
    return (String)field_176434_a.get(p_176433_1_);
  }
  



  public boolean onBlockEventReceived(World worldIn, BlockPos pos, IBlockState state, int eventID, int eventParam)
  {
    float var6 = (float)Math.pow(2.0D, (eventParam - 12) / 12.0D);
    worldIn.playSoundEffect(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D, "note." + func_176433_b(eventID), 3.0F, var6);
    worldIn.spawnParticle(EnumParticleTypes.NOTE, pos.getX() + 0.5D, pos.getY() + 1.2D, pos.getZ() + 0.5D, eventParam / 24.0D, 0.0D, 0.0D, new int[0]);
    return true;
  }
  



  public int getRenderType()
  {
    return 3;
  }
}
