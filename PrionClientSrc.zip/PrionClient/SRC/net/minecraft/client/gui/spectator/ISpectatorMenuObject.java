package net.minecraft.client.gui.spectator;

import net.minecraft.util.IChatComponent;

public abstract interface ISpectatorMenuObject
{
  public abstract void func_178661_a(SpectatorMenu paramSpectatorMenu);
  
  public abstract IChatComponent func_178664_z_();
  
  public abstract void func_178663_a(float paramFloat, int paramInt);
  
  public abstract boolean func_178662_A_();
}
