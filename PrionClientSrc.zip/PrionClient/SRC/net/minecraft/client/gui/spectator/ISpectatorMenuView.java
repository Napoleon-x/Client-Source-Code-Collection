package net.minecraft.client.gui.spectator;

import java.util.List;
import net.minecraft.util.IChatComponent;

public abstract interface ISpectatorMenuView
{
  public abstract List func_178669_a();
  
  public abstract IChatComponent func_178670_b();
}
