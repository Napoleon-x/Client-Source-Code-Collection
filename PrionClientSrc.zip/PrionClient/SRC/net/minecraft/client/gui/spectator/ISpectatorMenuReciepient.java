package net.minecraft.client.gui.spectator;

public abstract interface ISpectatorMenuReciepient
{
  public abstract void func_175257_a(SpectatorMenu paramSpectatorMenu);
}
