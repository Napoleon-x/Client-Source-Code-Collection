package com.darkmagician6.eventapi.types;

public class EventType
{
  public static final byte PRE = 0;
  public static final byte ON = 1;
  public static final byte POST = 2;
  public static final byte SEND = 3;
  public static final byte RECIEVE = 4;
  
  public EventType() {}
}
