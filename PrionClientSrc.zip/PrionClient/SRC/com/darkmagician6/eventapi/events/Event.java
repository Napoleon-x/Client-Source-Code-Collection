package com.darkmagician6.eventapi.events;

public abstract interface Event {}
