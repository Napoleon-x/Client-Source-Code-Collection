package com.darkmagician6.eventapi.events;

public abstract interface Typed
{
  public abstract byte getType();
}
