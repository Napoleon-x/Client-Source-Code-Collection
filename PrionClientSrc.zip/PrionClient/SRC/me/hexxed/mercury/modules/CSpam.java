package me.hexxed.mercury.modules;

import me.hexxed.mercury.modulebase.Module;
import me.hexxed.mercury.modulebase.ModuleCategory;
import me.hexxed.mercury.util.Util;




public class CSpam
  extends Module
{
  public CSpam()
  {
    super("CSpam", 0, true, ModuleCategory.MISC);
  }
  
  public void onEnable()
  {
    Util.sendInfo("Still need to fix dis nigger module");
  }
}
