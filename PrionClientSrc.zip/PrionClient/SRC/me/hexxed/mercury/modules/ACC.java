package me.hexxed.mercury.modules;

import me.hexxed.mercury.modulebase.Module;
import me.hexxed.mercury.modulebase.ModuleCategory;

public class ACC
  extends Module
{
  public ACC()
  {
    super("ACC", 0, false, ModuleCategory.MODES);
  }
}
