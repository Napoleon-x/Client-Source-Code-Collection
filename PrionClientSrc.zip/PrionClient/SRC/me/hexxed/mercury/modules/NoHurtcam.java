package me.hexxed.mercury.modules;

import me.hexxed.mercury.modulebase.Module;
import me.hexxed.mercury.modulebase.ModuleCategory;

public class NoHurtcam
  extends Module
{
  public NoHurtcam()
  {
    super("NoHurtcam", 0, true, ModuleCategory.RENDER);
  }
}
