package me.hexxed.mercury.modules;

import me.hexxed.mercury.modulebase.Module;
import me.hexxed.mercury.modulebase.ModuleCategory;

public class NoCheat
  extends Module
{
  public NoCheat()
  {
    super("NoCheat", 22, true, ModuleCategory.MODES);
  }
}
