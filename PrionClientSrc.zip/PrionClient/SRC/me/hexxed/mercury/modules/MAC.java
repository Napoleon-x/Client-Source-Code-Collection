package me.hexxed.mercury.modules;

public class MAC
{
  public MAC() {}
}
