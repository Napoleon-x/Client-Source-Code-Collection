package me.hexxed.mercury.commands;

import me.hexxed.mercury.modulebase.Module;
import me.hexxed.mercury.modulebase.ModuleCategory;

public class Stream
  extends Module
{
  public Stream()
  {
    super("Stream", 0, true, ModuleCategory.MISC);
  }
}
