package me.hexxed.mercury.ttf;

import net.minecraft.client.gui.FontRenderer;



















public class TTFRenderer
  extends FontRenderer
{
  public StringCache stringCache;
  int i11;
  
  public TTFRenderer(String paramString, int paramInt) {}
  
  private int renderString(String paramString, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    throw new Error("Unresolved compilation problems: \n\tThe field FontRenderer.red is not visible\n\tThe field FontRenderer.blue is not visible\n\tThe field FontRenderer.green is not visible\n\tThe field FontRenderer.alpha is not visible\n\tThe field FontRenderer.red is not visible\n\tThe field FontRenderer.blue is not visible\n\tThe field FontRenderer.green is not visible\n\tThe field FontRenderer.alpha is not visible\n\tThe field FontRenderer.posX is not visible\n\tThe field FontRenderer.posY is not visible\n\tThe field FontRenderer.posX is not visible\n\tThe field FontRenderer.posX is not visible\n");
  }
  











  private void resetStyles()
  {
    throw new Error("Unresolved compilation problems: \n\tThe field FontRenderer.randomStyle is not visible\n\tThe field FontRenderer.boldStyle is not visible\n\tThe field FontRenderer.italicStyle is not visible\n\tThe field FontRenderer.underlineStyle is not visible\n\tThe field FontRenderer.strikethroughStyle is not visible\n");
  }
  

























  public int drawString(String string, int x, int y, int color)
  {
    return drawString(string, x, y, color);
  }
  
  public int getStringWidth(String string) {
    return stringCache.getStringWidth(string);
  }
}
