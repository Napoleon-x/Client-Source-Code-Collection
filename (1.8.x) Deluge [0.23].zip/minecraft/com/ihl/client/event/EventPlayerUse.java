package com.ihl.client.event;

public class EventPlayerUse extends Event {

    public EventPlayerUse(Type type) {
        super(type);
    }

}
