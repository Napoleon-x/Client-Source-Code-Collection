package com.ihl.client.module.option;

public class ValueString extends Value {

    public ValueString(String value) {
        super(value);
    }

}
