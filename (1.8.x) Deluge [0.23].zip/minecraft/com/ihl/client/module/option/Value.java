package com.ihl.client.module.option;

public class Value {

    public Object value;

    public Value(Object value) {
        this.value = value;
    }

}
