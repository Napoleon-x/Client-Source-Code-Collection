package com.ihl.client.commands.exceptions;

public class SyntaxException extends CommandException {

}
