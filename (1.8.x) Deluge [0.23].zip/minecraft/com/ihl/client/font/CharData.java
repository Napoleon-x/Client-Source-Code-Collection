package com.ihl.client.font;

public class CharData {
    public int width;
    public int height;
    public int storedX;
    public int storedY;

    protected CharData(CFont paramCFont) {
    }
}
